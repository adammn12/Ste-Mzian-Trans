import { useState, type FormEvent } from "react";
import emailjs from "@emailjs/browser";

// --- Configuration EmailJS ---
// 1. Crée un compte gratuit sur https://www.emailjs.com
// 2. Connecte ta boîte Gmail (stemziantrans@gmail.com) comme "Service" -> récupère le SERVICE_ID
// 3. Crée un "Email Template" avec les variables {{name}}, {{company}}, {{email}}, {{phone}}, {{need}}, {{message}} -> récupère le TEMPLATE_ID
// 4. Dans "Account" > "General", récupère ta "Public Key"
// 5. Remplace les 3 valeurs ci-dessous
const EMAILJS_SERVICE_ID = "service_a5p4yh8";
const EMAILJS_TEMPLATE_ID = "template_bdvck68";
const EMAILJS_PUBLIC_KEY = "LpLKFydWe-4fvqmHs";

type IconName =
  | "arrow-up-right"
  | "arrow-right"
  | "truck"
  | "globe"
  | "route"
  | "warehouse"
  | "shield"
  | "clock"
  | "leaf"
  | "users"
  | "phone"
  | "mail"
  | "map-pin"
  | "menu"
  | "close"
  | "check"
  | "quote";

const heroImage = "/smt-truck-hero.jpg";
const fleetImage = "/smt-truck-fleet.jpg";
const warehouseImage = "/smt-truck-night.jpg";
const driverImage = "/smt-truck-driver.jpg";
const adamImage = "/adam-mzian.jpg";
const aymenImage = "/aymen-mzian.jpg";

const navigation = [
  { label: "L'histoire", href: "#histoire" },
  { label: "Nos services", href: "#services" },
  { label: "La flotte", href: "#flotte" },
  { label: "Engagement", href: "#engagement" },
];

const stats = [
  { value: "20+", label: "camions Volvo & Scania", detail: "Une flotte suivie au quotidien" },
  { value: "8", label: "ans sur les routes", detail: "Une expérience qui se construit" },
  { value: "3", label: "corridors maîtrisés", detail: "Maroc, Europe & Maghreb" },
  { value: "98%", label: "de clients satisfaits", detail: "La confiance, livrée" },
];

const services: { number: string; title: string; description: string; icon: IconName }[] = [
  { number: "01", title: "Transport national", description: "Des livraisons régulières et ponctuelles partout au Maroc.", icon: "truck" },
  { number: "02", title: "Import / Export", description: "Vos flux internationaux coordonnés de bout en bout.", icon: "globe" },
  { number: "03", title: "Transit & dédouanement", description: "Un accompagnement précis pour simplifier chaque formalité.", icon: "route" },
  { number: "04", title: "Logistique & entreposage", description: "Des solutions de stockage pensées pour vos cadences.", icon: "warehouse" },
  { number: "05", title: "Transport sur mesure", description: "Un dispositif agile, dessiné autour de votre activité.", icon: "shield" },
];

const founders: { name: string; role: string; image: string; description: string }[] = [
  {
    name: "Adam Mzian",
    role: "Cofondateur · Direction",
    image: adamImage,
    description: "À la tête de la stratégie et des relations clients, Adam veille à ce que chaque engagement pris par SMT soit tenu, avec la rigueur d'un pilote qui connaît chaque kilomètre de la route.",
  },
  {
    name: "Aymen Mzian",
    role: "Cofondateur · Opérations",
    image: aymenImage,
    description: "Sur le terrain aux côtés des équipes et de la flotte, Aymen orchestre les opérations au quotidien pour que chaque trajet reste fluide, sûr et ponctuel.",
  },
];

const commitments: { title: string; description: string; icon: IconName }[] = [
  { title: "Excellence opérationnelle", description: "Des process clairs, un suivi sans approximation.", icon: "route" },
  { title: "Proximité & confiance", description: "Une entreprise familiale, présente à chaque étape.", icon: "users" },
  { title: "Ponctualité", description: "Parce qu'un délai tenu est un engagement tenu.", icon: "clock" },
  { title: "Sécurité des marchandises", description: "Une flotte entretenue et des équipes formées.", icon: "shield" },
  { title: "Logistique responsable", description: "Des décisions durables, sur la route comme au dépôt.", icon: "leaf" },
];

function Icon({ name, size = 20 }: { name: IconName; size?: number }) {
  const props = {
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 1.7,
    strokeLinecap: "round" as const,
    strokeLinejoin: "round" as const,
    "aria-hidden": true,
  };

  switch (name) {
    case "arrow-up-right":
      return <svg {...props}><path d="M7 17 17 7" /><path d="M7 7h10v10" /></svg>;
    case "arrow-right":
      return <svg {...props}><path d="M5 12h14" /><path d="m13 6 6 6-6 6" /></svg>;
    case "truck":
      return <svg {...props}><path d="M3 6h11v11H3z" /><path d="M14 10h4l3 3v4h-7z" /><circle cx="7" cy="19" r="2" /><circle cx="18" cy="19" r="2" /><path d="M14 14h7" /></svg>;
    case "globe":
      return <svg {...props}><circle cx="12" cy="12" r="9" /><path d="M3 12h18M12 3c2.2 2.4 3.3 5.4 3.3 9S14.2 18.6 12 21c-2.2-2.4-3.3-5.4-3.3-9S9.8 5.4 12 3Z" /></svg>;
    case "route":
      return <svg {...props}><circle cx="6" cy="5" r="2" /><circle cx="18" cy="19" r="2" /><path d="M6 7v2c0 2 1.5 3 3.5 3h5c2 0 3.5 1 3.5 3v2" /></svg>;
    case "warehouse":
      return <svg {...props}><path d="m3 10 9-6 9 6v9H3z" /><path d="M7 19v-5h10v5M7 10h10M9 10v4M15 10v4" /></svg>;
    case "shield":
      return <svg {...props}><path d="M12 21s8-3.7 8-10V5l-8-3-8 3v6c0 6.3 8 10 8 10Z" /><path d="m9 12 2 2 4-4" /></svg>;
    case "clock":
      return <svg {...props}><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></svg>;
    case "leaf":
      return <svg {...props}><path d="M20 4C11 4 5 7 5 13c0 4 3 7 7 7 6 0 8-6 8-16Z" /><path d="M4 20c2-4 5-7 11-9" /></svg>;
    case "users":
      return <svg {...props}><circle cx="9" cy="8" r="3" /><path d="M3 20c0-3.5 2.5-6 6-6s6 2.5 6 6M16 5.5a3 3 0 0 1 0 5.8M18 14c1.8.8 3 2.8 3 5" /></svg>;
    case "phone":
      return <svg {...props}><path d="M6.5 3.5 9 3l2 5-2 1.5a15 15 0 0 0 5.5 5.5l1.5-2 5 2-.5 2.5c-.3 1.4-1.6 2.4-3 2.2C9.4 18.6 5.4 14.6 4.3 6.5c-.2-1.4.8-2.7 2.2-3Z" /></svg>;
    case "mail":
      return <svg {...props}><rect x="3" y="5" width="18" height="14" rx="1" /><path d="m3 7 9 6 9-6" /></svg>;
    case "map-pin":
      return <svg {...props}><path d="M20 10c0 5-8 11-8 11S4 15 4 10a8 8 0 1 1 16 0Z" /><circle cx="12" cy="10" r="2.5" /></svg>;
    case "menu":
      return <svg {...props}><path d="M4 7h16M4 12h16M4 17h16" /></svg>;
    case "close":
      return <svg {...props}><path d="m6 6 12 12M18 6 6 18" /></svg>;
    case "check":
      return <svg {...props}><path d="m5 12 4 4L19 6" /></svg>;
    case "quote":
      return <svg {...props}><path d="M6 17H4l1-5h2V8h5v4a5 5 0 0 1-4 5h-2Zm9 0h-2l1-5h2V8h5v4a5 5 0 0 1-4 5h-2Z" /></svg>;
  }
}

function Logo() {
  return (
    <a className="logo" href="#top" aria-label="SMT, retour en haut">
      <span className="logo-badge">
        <img src="/smt-logo.png" alt="SMT - Société Mzian Transport" />
      </span>
      <span className="logo-copy">
        <strong>Société Mzian Transport</strong>
        <small>Transit & logistique</small>
      </span>
    </a>
  );
}

export default function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isSending, setIsSending] = useState(false);

  const whatsappNumber = "212771158302";

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const form = event.currentTarget;
    const data = new FormData(form);
    const name = data.get("name")?.toString().trim() || "";
    const company = data.get("company")?.toString().trim() || "";
    const email = data.get("email")?.toString().trim() || "";
    const phone = data.get("phone")?.toString().trim() || "";
    const need = data.get("need")?.toString().trim() || "";
    const message = data.get("message")?.toString().trim() || "";

    setIsSending(true);

    // Envoi de l'email via EmailJS vers stemziantrans@gmail.com
    try {
      await emailjs.send(
        EMAILJS_SERVICE_ID,
        EMAILJS_TEMPLATE_ID,
        { name, company, email, phone, need, message },
        { publicKey: EMAILJS_PUBLIC_KEY }
      );
    } catch (error) {
      console.error("Erreur EmailJS:", error);
    }

    const whatsappMessage = [
      "Nouvelle demande de devis - SMT",
      `Nom: ${name}`,
      `Entreprise: ${company}`,
      `Email: ${email}`,
      `Téléphone: ${phone}`,
      `Besoin: ${need}`,
      message ? `Détails: ${message}` : null,
    ]
      .filter(Boolean)
      .join("\n");

    const whatsappUrl = `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(whatsappMessage)}`;
    window.open(whatsappUrl, "_blank", "noopener,noreferrer");

    setIsSending(false);
    setIsSubmitted(true);
  };

  const closeMenu = () => setIsMenuOpen(false);

  return (
    <div className="site-shell" id="top">
      <header className="site-header">
        <div className="container header-inner">
          <Logo />
          <nav className={`main-nav ${isMenuOpen ? "is-open" : ""}`} aria-label="Navigation principale">
            {navigation.map((item) => (
              <a key={item.href} href={item.href} onClick={closeMenu}>{item.label}</a>
            ))}
            <a className="nav-mobile-cta" href="#contact" onClick={closeMenu}>Demander un devis <Icon name="arrow-up-right" size={16} /></a>
          </nav>
          <a className="header-cta" href="#contact">Demander un devis <Icon name="arrow-up-right" size={16} /></a>
          <button className="menu-toggle" type="button" aria-label={isMenuOpen ? "Fermer le menu" : "Ouvrir le menu"} aria-expanded={isMenuOpen} onClick={() => setIsMenuOpen((open) => !open)}>
            <Icon name={isMenuOpen ? "close" : "menu"} size={22} />
          </button>
        </div>
      </header>

      <main>
        <section className="hero" style={{ backgroundImage: `url(${heroImage})` }} aria-label="SMT, transport et logistique">
          <div className="hero-overlay" />
          <div className="container hero-content">
            <div className="hero-copy">
              <p className="eyebrow"><span className="eyebrow-dot" /> Société Mzian Transport <span className="eyebrow-line" /> Aïn Sebaâ, Casablanca</p>
              <h1>Le mouvement juste.<br /><em>Au bon moment.</em></h1>
              <p className="hero-description">Nous orchestrons vos flux entre le Maroc et le monde avec la précision d&apos;un partenaire qui connaît la route.</p>
              <div className="hero-actions">
                <a className="button button-primary" href="#contact">Parler de votre projet <Icon name="arrow-up-right" size={17} /></a>
                <a className="text-link light-link" href="#flotte">Découvrir notre flotte <Icon name="arrow-right" size={17} /></a>
              </div>
            </div>
            <div className="hero-footer">
              <span>MAROC</span><i /> <span>EUROPE</span><i /> <span>MAGHREB</span>
              <span className="hero-scroll">Faire défiler <span className="scroll-line" /></span>
            </div>
          </div>
        </section>

        <section className="intro-section" id="confiance">
          <div className="container">
            <div className="section-intro intro-grid">
              <div>
                <p className="eyebrow eyebrow-dark"><span className="eyebrow-dot" /> SMT en mouvement</p>
                <h2>Une chaîne logistique qui ne laisse rien au hasard.</h2>
              </div>
              <div className="intro-aside">
                <p>De la prise en charge à la livraison, nous faisons circuler vos marchandises avec méthode, transparence et une vraie culture du résultat.</p>
                <a className="text-link dark-link" href="#services">Voir nos expertises <Icon name="arrow-right" size={17} /></a>
              </div>
            </div>
            <div className="stats-grid">
              {stats.map((stat) => (
                <div className="stat-item" key={stat.label}>
                  <strong>{stat.value}</strong>
                  <span>{stat.label}</span>
                  <small>{stat.detail}</small>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="story-section" id="histoire">
          <div className="container story-grid">
            <div className="story-images">
              <div className="story-photo story-photo-main">
                <img src={adamImage} alt="Adam Mzian, cofondateur de SMT" />
                <span className="photo-caption">Une aventure née à Casablanca</span>
              </div>
              <div className="story-photo story-photo-small">
                <img src={aymenImage} alt="Aymen Mzian, cofondateur de SMT, devant un camion Scania" />
                <span className="photo-index">01 / 02</span>
              </div>
              <div className="story-stamp">Depuis<br /><strong>2016</strong></div>
            </div>
            <div className="story-copy">
              <p className="eyebrow eyebrow-dark"><span className="eyebrow-dot" /> Notre histoire</p>
              <h2>Deux frères.<br /><span>Un même cap.</span></h2>
              <p className="story-lead">SMT est née d&apos;une conviction simple : les meilleures routes sont celles que l&apos;on construit avec ses clients.</p>
              <p>Adam et Aymen Mzian ont transformé leur connaissance du terrain en une entreprise familiale exigeante, à taille humaine. Aujourd&apos;hui, chaque mission porte leur signature : une relation directe, des décisions rapides et une parole tenue.</p>
              <div className="founder-signatures">
                <div><strong>Adam Mzian</strong><span>Cofondateur &middot; Direction</span></div>
                <div><strong>Aymen Mzian</strong><span>Cofondateur &middot; Opérations</span></div>
              </div>
              <a className="text-link dark-link" href="#engagement">Ce qui nous guide <Icon name="arrow-right" size={17} /></a>
            </div>
          </div>
        </section>

        <section className="founders-section">
          <div className="container">
            <div className="founders-heading">
              <p className="eyebrow eyebrow-dark"><span className="eyebrow-dot" /> Les visages de SMT</p>
              <h2>Ceux qui portent<br /><span>l&apos;entreprise.</span></h2>
            </div>
            <div className="founders-grid">
              {founders.map((founder) => (
                <div className="founder-card" key={founder.name}>
                  <div className="founder-photo">
                    <img src={founder.image} alt={`${founder.name}, ${founder.role}`} />
                  </div>
                  <div className="founder-info">
                    <p className="founder-role">{founder.role}</p>
                    <h3>{founder.name}</h3>
                    <p className="founder-description">{founder.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="services-section" id="services">
          <div className="container">
            <div className="section-heading-row">
              <div>
                <p className="eyebrow eyebrow-dark"><span className="eyebrow-dot" /> Nos expertises</p>
                <h2>Un seul partenaire.<br /><span>Toutes vos routes.</span></h2>
              </div>
              <p className="heading-note">Des solutions pensées pour garder une longueur d&apos;avance, même lorsque vos flux accélèrent.</p>
            </div>
            <div className="services-layout">
              <div className="service-list">
                {services.map((service) => (
                  <a className="service-row" href="#contact" key={service.number}>
                    <span className="service-number">{service.number}</span>
                    <span className="service-icon"><Icon name={service.icon} size={23} /></span>
                    <span className="service-text"><strong>{service.title}</strong><small>{service.description}</small></span>
                    <span className="service-arrow"><Icon name="arrow-up-right" size={18} /></span>
                  </a>
                ))}
              </div>
              <div className="service-visual" style={{ backgroundImage: `url(${warehouseImage})` }}>
                <div className="service-visual-overlay" />
                <div className="service-visual-copy"><span>Une logistique</span><strong>qui avance.</strong><span className="service-visual-mark">SMT / 05</span></div>
              </div>
            </div>
          </div>
        </section>

        <section className="fleet-section" id="flotte">
          <div className="container fleet-grid">
            <div className="fleet-content">
              <p className="eyebrow"><span className="eyebrow-dot" /> Notre flotte</p>
              <h2>La puissance de la route.<br /><em>La maîtrise en plus.</em></h2>
              <p>Plus de 20 tracteurs Volvo et Scania composent un parc moderne, suivi et prêt à tenir la cadence de vos opérations.</p>
              <div className="fleet-specs">
                <div><strong>20+</strong><span>véhicules en parc</span></div>
                <div><strong>24/7</strong><span>suivi des opérations</span></div>
                <div><strong>100%</strong><span>maintenance planifiée</span></div>
              </div>
              <a className="button button-outline-light" href="#contact">Parler à un expert <Icon name="arrow-up-right" size={17} /></a>
            </div>
            <div className="fleet-visual">
              <img src={fleetImage} alt="Camion Scania SMT tractant un conteneur dans une rue de Casablanca" />
              <div className="fleet-visual-inset">
                <img src={driverImage} alt="Chauffeur SMT au volant d'un camion Scania aux couleurs de l'entreprise" />
              </div>
              <div className="fleet-tag"><span>Parc SMT</span><strong>Volvo / Scania</strong><small>Fiabilité sur chaque kilomètre</small></div>
            </div>
          </div>
        </section>

        <section className="engagement-section" id="engagement">
          <div className="container">
            <div className="engagement-heading">
              <div>
                <p className="eyebrow eyebrow-dark"><span className="eyebrow-dot" /> Nos engagements</p>
                <h2>Faire bien.<br /><span>Faire confiance.</span></h2>
              </div>
              <p>Notre métier est technique. Notre manière de l&apos;exercer reste profondément humaine.</p>
            </div>
            <div className="commitment-grid">
              {commitments.map((commitment, index) => (
                <div className={`commitment-item ${index === 0 ? "commitment-featured" : ""}`} key={commitment.title}>
                  <span className="commitment-icon"><Icon name={commitment.icon} size={22} /></span>
                  <span className="commitment-number">0{index + 1}</span>
                  <strong>{commitment.title}</strong>
                  <p>{commitment.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="contact-section" id="contact">
          <div className="container contact-grid">
            <div className="contact-copy">
              <p className="eyebrow eyebrow-dark"><span className="eyebrow-dot" /> Parlons transport</p>
              <h2>Un flux à organiser ?<br /><span>On s&apos;en occupe.</span></h2>
              <p>Décrivez-nous votre besoin. Notre équipe vous répond rapidement avec une première approche claire et concrète.</p>
              <div className="contact-details">
                <a href="tel:+212771158302"><span className="contact-icon"><Icon name="phone" size={18} /></span><span><small>Téléphone</small><strong>+212 771 15 83 02</strong></span></a>
                <a href="https://wa.me/212771158302" target="_blank" rel="noreferrer"><span className="contact-icon"><Icon name="phone" size={18} /></span><span><small>WhatsApp</small><strong>+212 771 15 83 02</strong></span></a>
                <a href="mailto:stemziantrans@gmail.com"><span className="contact-icon"><Icon name="mail" size={18} /></span><span><small>Email</small><strong>stemziantrans@gmail.com</strong></span></a>
                <div className="contact-address"><span className="contact-icon"><Icon name="map-pin" size={18} /></span><span><small>Nous trouver</small><strong>Aïn Sebaâ, Casablanca</strong></span></div>
              </div>
            </div>
            <div className="contact-form-wrap">
              {isSubmitted ? (
                <div className="success-message">
                  <span className="success-icon"><Icon name="check" size={28} /></span>
                  <p className="eyebrow eyebrow-dark"><span className="eyebrow-dot" /> Demande envoyée</p>
                  <h3>Merci pour votre confiance.</h3>
                  <p>Votre demande a été envoyée par email et transmise sur WhatsApp. Notre équipe SMT revient vers vous rapidement pour avancer sur votre projet.</p>
                  <button className="text-link dark-link reset-button" type="button" onClick={() => setIsSubmitted(false)}>Envoyer une autre demande <Icon name="arrow-right" size={17} /></button>
                </div>
              ) : (
                <form className="quote-form" onSubmit={handleSubmit}>
                  <div className="form-topline"><span>Demande de devis</span><span>01 / 01</span></div>
                  <h3>Construisons votre prochain trajet.</h3>
                  <div className="form-row">
                    <label>Nom complet<input required name="name" type="text" placeholder="Votre nom" /></label>
                    <label>Entreprise<input required name="company" type="text" placeholder="Votre entreprise" /></label>
                  </div>
                  <div className="form-row">
                    <label>Email professionnel<input required name="email" type="email" placeholder="vous@entreprise.ma" /></label>
                    <label>Téléphone<input required name="phone" type="tel" placeholder="+212 ..." /></label>
                  </div>
                  <label>Votre besoin<select name="need" defaultValue=""><option value="" disabled>Sélectionnez une expertise</option><option>Transport national</option><option>Import / Export</option><option>Transit et dédouanement</option><option>Logistique et entreposage</option><option>Transport sur mesure</option></select></label>
                  <label>Quelques détails<textarea name="message" rows={3} placeholder="Origine, destination, volume, contraintes..."></textarea></label>
                  <button className="button button-dark" type="submit" disabled={isSending}>{isSending ? "Envoi en cours..." : "Envoyer ma demande"} <Icon name="arrow-up-right" size={17} /></button>
                  <small className="form-note">Vos informations restent confidentielles et seront utilisées uniquement pour vous répondre.</small>
                </form>
              )}
            </div>
          </div>
          <div className="map-wrap">
            <iframe title="Localisation SMT à Aïn Sebaâ, Casablanca" src="https://www.openstreetmap.org/export/embed.html?bbox=-7.568%2C33.595%2C-7.475%2C33.645&layer=mapnik&marker=33.615%2C-7.522" loading="lazy" />
            <div className="map-label"><span className="map-pin-dot" /> SMT / Aïn Sebaâ, Casablanca</div>
          </div>
        </section>
      </main>

      <footer className="site-footer">
        <div className="container footer-main">
          <Logo />
          <p>Le partenaire qui fait avancer vos marchandises,<br />et vos ambitions.</p>
          <a className="footer-top" href="#top">Retour en haut <Icon name="arrow-up-right" size={16} /></a>
        </div>
        <div className="container footer-bottom"><span>© 2026 SMT - Société Mzian Transport</span><span>Transport & logistique depuis Casablanca</span><span>Conçu avec précision.</span></div>
      </footer>
    </div>
  );
}